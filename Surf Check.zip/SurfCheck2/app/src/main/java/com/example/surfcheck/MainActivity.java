package com.example.surfcheck;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button botao1 = findViewById(R.id.botao1);
        Button botao2 = findViewById(R.id.botao2);
        Button botao3 = findViewById(R.id.botao3);
        Button botao4 = findViewById(R.id.botao4);

        botao1.setOnClickListener(view ->{

            String url = "https://condicaoatual.com.br/praia-do-rosa/";

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));

            startActivity(intent);
        });

        botao2.setOnClickListener(view ->{
            String url = "https://condicaoatual.com.br/praia-dos-ingleses/";

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));

            startActivity(intent);
        });

        botao3.setOnClickListener(view ->{
            String url = "http://surfconnect.com.br/ipanema-posto-10/";

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));

            startActivity(intent);
        });

        botao4.setOnClickListener(view ->{
            String url = "http://surfconnect.com.br/pernambuco/";

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));

            startActivity(intent);
        });


    }

}